# 桌面版第三方声明（tonggan-desktop）

桌面壳为 Tauri 2 应用。直接依赖及其许可证（双许可者可按 Apache-2.0 或 MIT 任选）：

- tauri 2.x：**MIT OR Apache-2.0**
- tauri-plugin-global-shortcut 2.x：**（未标注）**
- global-hotkey 0.8：**（未标注）**
- screenshots 0.8.10：**（未标注）**
- image 0.24（经 screenshots re-export）：**（未标注）**
- base64 0.22：**（未标注）**
- serde / serde_json：**MIT OR Apache-2.0**

完整依赖闭包以随包 `Cargo.lock` 为准（每个 crate 的 license 字段见其 registry 清单）。
Apache-2.0 全文见 `web/public/tesseract/LICENSE`（与 Tauri 的 Apache 授权同一份文本）。
内嵌的 web 产物自身的第三方声明见 `web/third_party/`（liblouis zh-chn.ctb：LGPL-2.1-or-later；
tesseract.js / tesseract.js-core：Apache-2.0）与 `web/public/tessdata/NOTICE.md`。
