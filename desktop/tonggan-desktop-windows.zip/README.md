# 通感 TongGan 桌面版（Windows）

网页版做不到的三件事，由这层 Tauri 壳补上；**识别/播报/导出等全部功能仍是内嵌的 web 应用**
（`web/dist` 打进二进制，本目录不含任何第二套业务逻辑）：

| 能力 | 说明 |
|---|---|
| 全局快捷键 | 焦点在任何软件里都生效：`Alt+Shift+S` 截屏读屏、`Alt+Shift+X` 停读、`Alt+Shift+M` 迷你条、`Alt+Shift+T` 回主界面 |
| 后台常驻 | 关闭主窗口**不退出**：进程收进托盘与迷你条，正在播的语音继续 |
| 置顶迷你条 | 430×56 的无边框横条（右下角落位）：截屏读 / 停读 / 恢复 / 退出四个真按钮 + 当前播报字幕，占最小的屏幕空间 |

## 数据流（为什么不复制逻辑）

```
Alt+Shift+S ──► Rust: 截主屏 → PNG
                    │  window.__tgHotkey('capture-data', dataURL)   ← 一条注入通道
                    ▼
          web 应用 loadOneFile(与拖入图片同一条管线) → A11y-IR → 逐格播报
                    │  invoke('set_caption', 每句播报)              ← 一条回传命令
                    ▼
              迷你条字幕（与主界面无障碍字幕同一条口径）
```

## 构建（Windows，需 Rust + VS Build Tools + WebView2 运行时）

```bash
# 1) 先出 web 产物（桌面版把它整个内嵌进 exe）
cd ../../web && npm run build

# 2) 编译发布版（约 15MB 单文件，含 OCR 引擎与中英文语言包，装好即离线可用）
cd ../desktop/src-tauri && cargo build --release

# 3) 打包成站点下载件
powershell Compress-Archive -Force target/release/tonggan-desktop.exe ../../web/dist/desktop/tonggan-desktop-windows.zip
```

> 站点上的下载入口 `…/desktop/tonggan-desktop-windows.zip` 来自上一步第 3 条。
> **顺序是硬约束：web build → cargo release → 最后打 zip。**
> cargo 会把 frontendDist（web/dist）**整个内嵌**进 exe——如果那时 dist 里已经有
> 上一版 zip，它会被塞进新 exe（32MB→59MB，亲脚踩过，package-desktop.mjs 已加尺寸护栏）。
> dist/desktop/*.zip 不进 SW 预缓存（离线只缓存 assets 与页面），放在那里只为网页版下载。

## 已知边界（写清楚，不装）

- 仅构建 Windows x64；Linux/macOS 未做包（同一套代码可编译，发布需各自签名/打包流程）。
- 全局截屏抓**主显示器整屏**，走的是与实时读屏同一套 OCR：识别结果如实标降级与置信度，
  读不出就是读不出，不编数字。
- 首帧 OCR 需要联网取一次引擎与语言包（离线验收 12/12：之后完全离线）。
- 迷你条不抢焦点（`skip_taskbar`），四个按钮可用 Tab 聚焦、Enter 触发；
  它显示的字幕与主界面 `role=status` 是同一句（由 `set_caption` 回传）。
