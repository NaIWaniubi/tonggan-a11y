# 通感 TongGan 桌面版（Windows）

网页版做不到的三件事，由这层 Tauri 壳补上；**识别/播报/导出等全部功能仍是内嵌的 web 应用**
（`web/dist` 打进二进制，本目录不含任何第二套业务逻辑）：

| 能力 | 说明 |
|---|---|
| 全局快捷键 | 焦点在任何软件里都生效：`Alt+Shift+S` 截屏读屏、`Alt+Shift+X` 停读（语音+可听化+在途识别+实时循环全停）、`Alt+Shift+M` 迷你条、`Alt+Shift+T` 回主界面。某个组合键被别的软件占用时**不影响启动**，程序会念出是哪几个键不可用，托盘与迷你条照常用 |
| 后台常驻 | 关闭主窗口**不退出**：进程收进迷你条+托盘，正在播的语音继续；迷你条自身被 Alt+F4 也只是收起。真正退出走托盘/迷你条的「退出」 |
| 置顶迷你条 | 430×56 的无边框横条（主屏右下）：截屏读 / 停读 / 恢复 / 退出四个真按钮 + 当前字幕。字幕与主界面右侧大字幕同源（`set_caption` 回传），可拖动、Tab 可聚焦、错误会在条上明说 |

四个热键的真机验收记录（含 Win32 窗口枚举原文与「自己读自己」回归）见
[`web/EVIDENCE/desktop-hotkeys-realmachine.md`](../web/EVIDENCE/desktop-hotkeys-realmachine.md)。

## 数据流（为什么不复制逻辑）

```
Alt+Shift+S ─► Rust：先把自家窗口藏掉 → 截「光标所在屏」→ PNG
   │  window.__tgHotkey('capture-data', dataURL) + 15s capture_ack 看门狗
   ▼
web 应用 loadOneFile(与拖入图片同一条管线) → A11y-IR → 逐格播报
   │  invoke('set_caption', 每条字幕) → 迷你条镜像显示
   ▼
迷你条（页面就绪后主动 get_caption 握手补发，不赌 eval 时序）
```

截屏前藏窗、截完复原：否则置顶的迷你条会被拍进图里，自家按钮文字会被当成
表格内容念回来（独立评审抓到，「自己读自己」）。

## 构建（Windows x64；需 Rust + VS Build Tools + WebView2 运行时）

**顺序是硬约束**（每一步都有踩过的坑背书）：

```bash
# 1) 出 web 产物。此刻 dist 里【不得】有 desktop/*.zip——
#    cargo 会把 frontendDist 整个内嵌进 exe，带着旧 zip 就是自吞（32MB→59MB 踩过）。
cd ../../web && npm run build

# 2) 编译发布版（exe ≈32MB：含内嵌的 web 应用 + OCR 引擎 + 中英文语言包）
cd ../desktop/src-tauri && cargo build --release
mkdir -p ../release && cp target/release/tonggan-desktop.exe ../release/

# 3) 最后打包（zip = exe + README + 第三方声明，≈26.1MB）
cd ../../web && node tools/package-desktop.mjs
```

> - `package-desktop.mjs` 有 45MB 护栏：超限即拒绝，就是拦自吞的。
> - 任何一次 `vite build`（包括 `node tools/integration-gate.mjs` 内部那次）都会清空
>   dist——**跑过 gate 之后、部署之前，必须重新执行第 3 步**，否则站点下载按钮 404（踩过）。
> - zip 26.1MB 超过 Qoder Sites 单文件 25MB 上限，所以站内的下载按钮恒指向
>   GitHub Pages 的绝对地址；Qoder 侧部署时 `dist/desktop/` 可以不带。

## 离线与网络（桌面版与网页版口径不同，分开写清）

- 桌面版：引擎、wasm、中英文语言包**全部内嵌在 exe 里**，首次运行即可离线识别
  （不向任何第三方 CDN 发请求——`createWorker` 的 workerPath/corePath/langPath
  全部指向同源内嵌资源，评审复核过 CDN 字符串仅是库的默认值、已被显式覆盖）。
- 网页版：首次真用 OCR 需联网取一次引擎与语言包（约 30MB，来自站点自身、非第三方 CDN），
  之后断网可用（离线闸 12/12 含「断网后真实图片 OCR 出表」实测）。
- 两版共同：识别与导航全程本地完成，被读的数据不离开本机。

## 已知边界（写清楚，不装）

- 仅构建 Windows x64；未做代码签名（SmartScreen 提示「未知发布者」属预期）。
- 截屏取**光标所在显示器**；单显示器无感，多显示器符合「读我在看的」。
- 迷你条字幕是主界面字幕的镜像（随页面状态，不随声音）：关自语音用 NVDA 时同样有效。
- 首帧 OCR 的准确率是 Tesseract 的天花板：图标类非文字图形可能被糊成相近字形，
  产品做的是如实降级、标注置信度、说「这一格我不确定」，绝不把垃圾包装成可信数据。
- 粘贴：应用窗口聚焦时 `Ctrl+V` 贴图片或表格文件即识别；**全局热键粘贴**（在微信窗口里直接按组合键把剪贴板图片送给通感）尚未实现——全局键只送屏幕截图。
- 隐藏的主窗口里 `speechSynthesis` 出声依赖 WebView2 对后台页面语音的处理：
  真机已验证「迷你条触发→语音播报→字幕回传」全链路（见 EVIDENCE），
  但极端省电策略下的行为未穷尽——如遇不出声，Alt+Shift+T 唤回主窗口即恢复。
